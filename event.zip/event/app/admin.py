from .models import *
from django.contrib import admin

# Register your models here.
admin.site.register(Event)
admin.site.register(BookEvent)
admin.site.register(Enquiery)
admin.site.register(MainImage)
admin.site.register(SubImage)